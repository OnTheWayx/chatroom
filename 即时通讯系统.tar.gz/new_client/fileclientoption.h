#ifndef _FILECLIENTOPTION_H_
#define _FILECLIENTOPTION_H_

enum fileclientoption
{
    FILE_DOWNLOAD = 1000,
};

#endif // end of fileclientoption.h