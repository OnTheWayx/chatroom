#ifndef _CLIENTPOSITION_H_
#define _CLIENTPOSITION_H_

// 当前用户所在位置
enum positon
{
    POSI_MAINMENU = 1,
    POSI_CHATHALL

    /**
     * opt = POSI_MAINMENU --- 用户处于主菜单
     * opt = POSI_CHATHALL -- 用户处在聊天大厅
     * 
     */
};

#endif // end of clientposition.h